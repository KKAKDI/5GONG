package cuh.pm;

import cuh.back.Transfer;
import cuh.back.TransferImpl;

public class TsUser {
	public static void main(String[] args) {
		Transfer impl = new TransferImpl();
		boolean flag = impl.transfer("one@daum.net", "two@naver.com", 50000L);
		if(flag) {
			System.out.println("��ü ����");
		}else {
			System.out.println("��ü ����");
		}
		impl.showResult("one@daum.net", "two@naver.com");
		impl.closeAll();
	}
}
