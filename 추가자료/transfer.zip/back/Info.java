package cuh.back;

public class Info {
	public static final String url = "jdbc:oracle:thin:@127.0.0.1:1521:JAVA";
	public static final String usr = "scott";
	public static final String pwd = "tiger";
}
