package cuh.back;

import java.sql.*;
import java.util.Vector;

public class TransferImpl implements Transfer {
	Info info = new Info();
	Sql sql = new Sql();
	Connection con;
	Statement stmt;
	PreparedStatement pstmtSel1, pstmtSel2, pstmtSel3, pstmtUp1, pstmtUp2, pstmtUp3, pstmtIn;
	ResultSet rs;
	ResultSetMetaData rsmd;
	
	Vector<String> columnNames = new Vector<String>();
	Vector<Vector> rowData = new Vector<Vector>();

	public TransferImpl(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(info.url, info.usr, info.pwd);
			con.setAutoCommit(false);
			pstmtSel1 = con.prepareStatement(sql.sql1);
			pstmtSel2 = con.prepareStatement(sql.sql2);
			pstmtSel3 = con.prepareStatement(sql.sql6);
			pstmtUp1 = con.prepareStatement(sql.sql3);
			pstmtUp2 = con.prepareStatement(sql.sql4);
			pstmtUp3 = con.prepareStatement(sql.sql7);
			pstmtIn = con.prepareStatement(sql.sql5);

			System.out.println("���� ����");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("����Ŭ ����̹� �ε� ����");
		}catch(SQLException se) {
			System.out.println("����Ŭ ���� ����");
		}
	}

	public boolean isMember(String email) { //email ���� Ȯ��(SELECT)
		try {
			pstmtSel1.setString(1, email);
			rs = pstmtSel1.executeQuery();
			if(rs.next() == true) {
				System.out.println("��ȸ ����");
				return true;
			}else {
				System.out.println("��ȸ ����");
				return false;
			}
		}catch(SQLException se) {
			System.out.println("email ��ȸ ���� : " + se);
			return false;
		}
	}
	public boolean checkBalance(String sender, long amount) { //�����»�� �ܾ�Ȯ��(SELECT)
		try {
			pstmtSel2.setString(1, sender);
			rs = pstmtSel2.executeQuery();
			if(rs.next() == true) {
				long money = rs.getLong(1);
				//System.out.println(money);

				if(money >= amount) {
					System.out.println("�ܾ� Ȯ�� ����");
					return true;
				}else {
					System.out.println("�ܾ� Ȯ�� ����");
					return false;
				}
			}else {
				System.out.println("�ܾ�Ȯ�� ����");
				return false;
			}
		}catch(SQLException se) {
			System.out.println("�ܾ� Ȯ�� ���� : " + se);
			return false;
		}
	}
	public boolean minus(String sender, long amount) {//�����»�� �ݾ� minus(UPDATE)
		try {
			pstmtUp1.setString(1, sender);
			pstmtUp1.setLong(2, amount);
			pstmtUp1.setString(3, sender);
			int i = pstmtUp1.executeUpdate();
			if(i > 0) {
				System.out.println("���̳ʽ� ����");
				//con.commit();
				return true;
			}else {
				System.out.println("�Է� ����");
				return false;
			}
		}catch(SQLException se) {
			System.out.println("���̳ʽ� ���� : " + se);
			return false;
		}
	}
	public boolean plus(String receiver, long amount) {//�޴»�� �ݾ� plus(UPDATE)
		try {
			pstmtUp2.setString(1, receiver);
			pstmtUp2.setLong(2, amount);
			pstmtUp2.setString(3, receiver);
			int i = pstmtUp2.executeUpdate();
			if(i > 0) {
				System.out.println("�÷��� ����");
				//con.commit();
				return true;
			}else {
				System.out.println("�Է� ����");
				return false;
			}
		}catch(SQLException se) {
			System.out.println("�÷��� ���� : " + se);
			return false;
		}
	}
	
	public boolean udate(String sender, String receiver) {
		try {
			pstmtUp3.setString(1, sender);
			pstmtUp3.executeUpdate();
			pstmtUp3.setString(1, receiver);
			pstmtUp3.executeUpdate();
			return true;
		}catch(SQLException se) {
			System.out.println("udate ���� : " + se);
			return false;
		}
	}
	
	public boolean log(String sender, String receiver, long amount) {//�α�����(INSERT)
		try {
			pstmtIn.setString(1, sender);
			pstmtIn.setString(2, receiver);
			pstmtIn.setLong(3, amount);
			int i = pstmtIn.executeUpdate();
			if(i > 0) {
				System.out.println("�Է� ����");
				//con.commit();
				return true;
			}else {
				System.out.println("�Է� ����");
				return false;
			}
		}catch(SQLException se) {
			System.out.println("�Է� ���� : " + se);
			return false;
		}
	}
	public void showResult(String sender, String receiver) { //�����»���� �޴»���� �ܾ��� �����ش�(SELECT)
		try {
			pstmtSel3.setString(1, sender);
			pstmtSel3.setString(2, receiver);
			rs = pstmtSel3.executeQuery();
			rsmd = rs.getMetaData();
			int colCount = rsmd.getColumnCount();
			for(int i=1; i<=colCount; i++) {
				String colName = rsmd.getColumnName(i);
				System.out.printf(colName + "\t\t");
			}
			System.out.println();
			while(rs.next()) {
				//Vector<String> v = new Vector<String>();
				for(int i=1; i<=colCount; i++) {
					String colString = rs.getString(i);
					//v.add(colString);
					System.out.print(colString  + "\t");
				}
				System.out.println();
			}
		}catch(SQLException se) {
			System.out.println("�ܾ� Ȯ�� ���� : " + se);
		}
	}
	public void closeAll() { //�ݾ��ֱ����� �޼ҵ�
		try {
			if(pstmtIn != null) pstmtIn.close();
			if(pstmtUp3 != null) pstmtUp3.close();
			if(pstmtUp2 != null) pstmtUp2.close();
			if(pstmtUp1 != null) pstmtUp1.close();
			if(pstmtSel3 != null) pstmtSel3.close();
			if(pstmtSel2 != null) pstmtSel2.close();
			if(pstmtSel1 != null) pstmtSel1.close();
			if(rs != null) rs.close();
			if(con != null) con.close();
			
		}catch(Exception e) {}
	}

	//Connection�� commit()�� rollback()�޼ҵ� ����ؼ� AutoCommit�� ���´�(setAutoCommit(false)���ؼ� ����Ŀ���� ���´�)
	public boolean transfer(String sender, String receiver, long amount) {
		try {
			if(isMember(sender) && isMember(receiver) && checkBalance(sender, amount)  
				&& minus(sender, amount) && plus(receiver, amount) && udate(sender, receiver) 
				&& log(sender, receiver, amount)) {
						con.commit();
						return true;
			}else {
				con.rollback();
				return false;
			}
		}catch(SQLException se) {
			System.out.println("transfer ���� : " +se);
			return false;
		}
	}
}
