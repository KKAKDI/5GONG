var text = '{"members":['+ 
	'{"firstName":"혜원", "lastName":"최"},' + 
    '{"firstName":"승언", "lastName":"천"},' + 
    '{"firstName":"채현", "lastName":"정"}]}'; 

obj = JSON.parse(text);
document.getElementById("pId").innerHTML = "<font color='blue'>" + 
obj.members[1].firstName + " "+ obj.members[1].lastName + "</font>";


