drop table JSON_AJAX;
drop sequence JSON_AJAX_SEQ;

create table JSON_AJAX(NO number constraint JSON_AJAX_PK primary key, NAME varchar2(40), CITY varchar2(30), COUNTRY varchar2(30));
create sequence JSON_AJAX_SEQ increment by 1 start with 1 nocache;

insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Alfreds', 'Berlin', 'Germany');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Berglunds', 'Lulea', 'Sweden');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Centro', 'Mexico', 'Mexico');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Ernst', 'Graz', 'Austria');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'FISSA', 'Madrid', 'Spain');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Galeria', 'Barcelona', 'Spain');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Island', 'Cowes', 'UK');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Koniglich', 'Brandenburg', 'Germany');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Laughing', 'Vancouver', 'Canada');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Magazzini', 'Bergamo', 'Italy');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'North', 'London', 'UK');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Paris', 'Paris', 'France');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Rattlesnake', 'Albuquerque', 'USA');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Simons', 'Kobenhavn', 'Denmark');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'The Big Cheese', 'Portland', 'USA');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Vaffe', 'Arhus', 'Denmark');
insert into JSON_AJAX values(JSON_AJAX_SEQ.nextval, 'Wolski', 'Warszawa', 'Poland');

commit;

select * from JSON_AJAX order by no;		