package kjh.member.model;

import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MemberDAO {
	private DataSource ds;
	
	public MemberDAO(){
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/myoracle");
		} catch (NamingException e) {
			System.out.println(e);
		}
	}
	
	public MemberDTO getMem(MemberDTO Mem) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberDTO outMem = null;
		try {
			con = ds.getConnection();			
			pstmt = con.prepareStatement(MemberSQL.SQL_SEL);
			pstmt.setString(1, Mem.getId());
			pstmt.setString(2, Mem.getPw());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				outMem = new MemberDTO();
				outMem.setId(rs.getString(4));
				outMem.setPw(null);
			}			
		} catch (SQLException se) {
			System.out.println(se);
		}
		return outMem;
	}
	void inMem(MemberDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(MemberSQL.SQL_IN);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getSsn());
			pstmt.setString(3, dto.getId());
			pstmt.setString(4, dto.getPw());
			pstmt.setString(5, dto.getEmail());
			pstmt.setString(6, dto.getPhone());
			pstmt.executeUpdate();
		} catch (SQLException se) {
			System.out.println(se);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}
}
