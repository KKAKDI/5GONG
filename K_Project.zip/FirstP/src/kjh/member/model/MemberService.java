package kjh.member.model;

import java.util.*;

public class MemberService {
	private MemberDAO dao;
	private static MemberService instance = new MemberService();
	
	private MemberService() {
		dao = new MemberDAO();
	}
	public static MemberService getInstance() {
		return instance;
	}
	public void insertS(MemberDTO dto) {
		dao.inMem(dto);
	}
}
