package kjh.member.model;

public class MemberSQL {
	static final String SQL_IN = "insert into MEMBER values(MEMBER_NO.nextval,?,?,?,?,?,?,SYSDATE)";
	static final String SQL_SEL = "select * from MEMBER where ID=? and PWD=?";	
}
