package kjh.member.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import kjh.member.model.MemberDAO;
import kjh.member.model.MemberDTO;
import kjh.member.model.MemberService;

@WebServlet("/login.do")
public class MemberControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String m = request.getParameter("m");

		if (m != null) {
			m = m.trim();
			if (m.equals("in")) {
				login(request, response);
			} else if (m.equals("out")) {
				logout(request, response);
			} else if(m.equals("new_form")) {
				newForm(request, response);
			} else if(m.equals("new")) {
				signup(request, response);
			}
		} else {
			loginSession(request, response);
		}
	}

	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	public void newForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("loginForm.jsp");
	}
	public void signup(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String ssn = request.getParameter("ssn");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String mail1 = request.getParameter("mail1");
		String mail2 = request.getParameter("mail2");
		String email = mail1+"@"+mail2;
		String phone = request.getParameter("phone");
		java.sql.Date joindate = null;
		MemberDTO dto = new MemberDTO(-1,name,ssn,id,pwd,email,phone,joindate);
		MemberService service = MemberService.getInstance();
		service.insertS(dto);
		response.sendRedirect("index.do");
	}

	public void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect("index.do");
	}

	protected void loginSession(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		MemberDTO inMem = new MemberDTO();
		inMem.setId(id);
		inMem.setPw(pwd);
		MemberDAO dao = new MemberDAO();
		MemberDTO outMem = dao.getMem(inMem);
		if (outMem == null) {	
			out.println("<script>alert('���̵�, �н����带 Ȯ�����ּ���.');location.href='login.do?m=in';</script>");			
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("session_id", outMem.getId());	
			System.out.println(outMem.getId());
			//response.sendRedirect("index.do");		
			out.println("<script>alert('"+id+" ���� �α���');location.href='index.do';</script>");
		}
	}
}
