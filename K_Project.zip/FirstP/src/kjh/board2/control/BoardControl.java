package kjh.board2.control;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import kjh.board2.model.BoardDTO;
import kjh.board2.model.BoardService;
import kjh.coment.model.ComentDTO;
import kjh.coment.model.ComentService;

@WebServlet("/board2.do")
public class BoardControl extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String m = request.getParameter("m");
		if(m != null) {
			m = m.trim();			
			if(m.equals("in_form")) {
				in_form(request, response);
			}else if(m.equals("in")) {
				insert(request, response);
			}else if(m.equals("con")) {
				content(request, response);
			}else if(m.equals("del")) {
				delete(request, response);
			}else if(m.equals("up_form")) {
				updateForm(request, response);
			}else if(m.equals("up")) {
				//update(request, response);
			}else if(m.equals("re_form")) {
				rewriteForm(request, response);
			}else if(m.equals("rewrite")){
				rewrite(request, response);
			}else if(m.equals("reply")) {
				reply(request, response);
			}else {
				list(request, response);
			}
		}else {
			System.out.println("�Ķ���� ����");
			list(request, response);
		}
	}
	private void reply(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int seq = getSeq(request);
		String look = request.getParameter("look");
		String id = request.getParameter("id");	
		String content = request.getParameter("content_reply");
		String pwd = request.getParameter("pwd_reply");
		System.out.println(seq+"/"+look+"/"+id+"/"+content+"/"+pwd);
		ComentDTO dto = new ComentDTO(-1,id,pwd,content,null,id,seq);		
		ComentService service = ComentService.getInstance();
		service.inCmS(dto);		
		String param = "board2.do?m=con&seq="+seq+"&look="+look;
		response.sendRedirect(param);
	}
	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BoardService service = BoardService.getInstance();
		String searchKey = request.getParameter("searchKey");
		String searchValue = request.getParameter("searchValue");
		String pageStr = request.getParameter("pg");
				
		int rowCnt = 5;
		int page = 1;
		
		if(pageStr!=null) {//page �� �ʱⰪ�� �ƴ� ��� ����
			page = Integer.parseInt(pageStr);
		}
		
		int begin =(page*rowCnt)-(rowCnt-1);// 2x5-4
		int end =(page*rowCnt);//2x5 
		
		
		int total = service.getTotalS();
		int allPage = (int)Math.ceil(total/(double)rowCnt);
		int block = 3;
		
		int fromPage= ((page-1)/block*block)+1;
		int toPage = ((page-1)/block*block)+block;
		if(toPage>allPage) {
			toPage=allPage;
		}	
		ArrayList<BoardDTO> list = service.selectS(searchKey, searchValue,begin,end);				
		request.setAttribute("page", page);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);
		request.setAttribute("allPage", allPage);		
		request.setAttribute("block", block);		
		request.setAttribute("list", list);
		RequestDispatcher rd = request.getRequestDispatcher("board2/board_list.jsp");
		rd.forward(request, response);
	}
	
	private void in_form(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("board2/board_input.jsp");
	}
	
	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		String saveDir = sc.getRealPath("file/store");
		System.out.println("saveDir : " + saveDir);
		int maxPostSize = 1*1028*1028;
		String encoding = "utf-8";
		FileRenamePolicy policy = new DefaultFileRenamePolicy();
		
		MultipartRequest mr = new MultipartRequest(request, saveDir, maxPostSize, encoding, policy); 
		String fname = mr.getFilesystemName("fname");
		String ofname = mr.getOriginalFileName("fname");
		
		String subject = mr.getParameter("subject");
		String content = mr.getParameter("content");
		String writer = mr.getParameter("writer");
		String email = mr.getParameter("email");
		String homepage = mr.getParameter("homepage");
		String pwd = mr.getParameter("pwd");
		
		BoardService service = BoardService.getInstance();
		BoardDTO dto = new BoardDTO(-1, subject, content, writer, null, 0, email, homepage, pwd, fname, ofname, -1,-1,-1);
		service.insertS(dto);
		response.sendRedirect("board2.do");
	}
	
	private void content(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int result = 0;
		String seqStr = request.getParameter("seq");
		String lookStr = request.getParameter("look");
		seqStr = seqStr.trim();
		lookStr = lookStr.trim();
		int look = Integer.parseInt(lookStr);
		int seq = Integer.parseInt(seqStr);
		//��ȸ�� ��Ű
		Cookie[] cookies = request.getCookies();
		Cookie viewCookie = null;
		BoardService service = BoardService.getInstance();
		BoardDTO dto = service.contentS(seq);
				
		if(cookies !=null && cookies.length>0) {
			for(int i=0;i<cookies.length; i++) {
				if(cookies[i].getName().equals("cookie"+seq)) {
					viewCookie = cookies[i];					
				}
			}
		}
		if(viewCookie==null) {
			Cookie newCookie = new Cookie("cookie"+seq,"/"+seq+"/");
			response.addCookie(newCookie);
			result = lookUp(request,response);		
			dto.setLookup(result);
		}else {
			result = look;
		}
		//���
		ComentService cservice = ComentService.getInstance();
		ArrayList<ComentDTO> clist = cservice.selCmS(seq);
		request.setAttribute("reply", clist);
		request.setAttribute("con", dto);
		RequestDispatcher rd = request.getRequestDispatcher("board2/board_content.jsp");
		rd.forward(request, response);
	}
	private int lookUp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String seqStr = request.getParameter("seq");
		String lookStr = request.getParameter("look");
		seqStr = seqStr.trim();
		lookStr = lookStr.trim();
		int look = Integer.parseInt(lookStr);
		int seq = Integer.parseInt(seqStr);		
		BoardService service = BoardService.getInstance();
		BoardDTO inLook = new BoardDTO();
		inLook.setSeq(seq);		
		inLook.setLookup(look+1);
		
		return service.lookUpS(inLook);		
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		String saveDir = sc.getRealPath("/file/store");
		int seq = getSeq(request);
		String fname = request.getParameter("fname");
		File f = new File(saveDir, fname);
		BoardService service = BoardService.getInstance();
		service.deleteS(seq);
		if(f.exists()) {
			f.delete();
		}
		response.sendRedirect("board2.do");
	}
	
	private void updateForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String seqStr = request.getParameter("seq");
		seqStr = seqStr.trim();
		int seq = Integer.parseInt(seqStr);
		BoardService service = BoardService.getInstance();
		BoardDTO dto = service.contentS(seq);
		request.setAttribute("up_form", dto);
		RequestDispatcher rd = request.getRequestDispatcher("board2/board_update_form.jsp");
		rd.forward(request, response);
	}
	
	private void rewriteForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int seq = getSeq(request);
		BoardService service = BoardService.getInstance();
		BoardDTO dto = service.rewriteFormS(seq);
		request.setAttribute("re_form", dto);
		RequestDispatcher rd = request.getRequestDispatcher("board2/board_rewrite_form.jsp");
		rd.forward(request, response);
	}
	
	private void rewrite(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext sc = getServletContext();
		String saveDir = sc.getRealPath("file/store");
		System.out.println("saveDir : " + saveDir);
		int maxPostSize = 1*1028*1028;
		String encoding = "utf-8";
		FileRenamePolicy policy = new DefaultFileRenamePolicy();
		
		MultipartRequest mr = new MultipartRequest(request, saveDir, maxPostSize, encoding, policy); 
		String fname = mr.getFilesystemName("fname");
		String ofname = mr.getOriginalFileName("fname");
		String bnStr = mr.getParameter("num");
		String blStr = mr.getParameter("lev");
		String sbStr = mr.getParameter("sb");
		
		bnStr = bnStr.trim();	
		blStr = blStr.trim();
		sbStr = sbStr.trim();
		int bn = Integer.parseInt(bnStr);
		int bl = Integer.parseInt(blStr);
		int sb = Integer.parseInt(sbStr);
		
		String subject = mr.getParameter("subject");
		String content = mr.getParameter("content");
		String writer = mr.getParameter("writer");
		String email = mr.getParameter("email");
		String homepage = mr.getParameter("homepage");
		String pwd = mr.getParameter("pwd");		
		
		
		BoardService service =BoardService.getInstance();
		bl = bl+1;
		//�������ϱ�
		sb = sb+1;
		//������ ���� ���� ���� ����(sb���� ���ų� ū �ֵ� +1)
		service.sbUpdateS(bn,sb);		
		BoardDTO dto = new BoardDTO(-1,subject,content,writer,null,0,email,homepage,pwd,fname,ofname,bn,bl,sb);
		service.rewriteS(dto);
	
		
		response.sendRedirect("board2.do");
	}
	
	private int getSeq(HttpServletRequest request) {
		int seq = -1;
		String seqStr = request.getParameter("seq");
		if(seqStr != null) {
			seqStr = seqStr.trim();
			if(seqStr.length() != 0) {
				try {
					seq = Integer.parseInt(seqStr);
					return seq;
				}catch(NumberFormatException ne) {
					System.out.println("������ ���°� �ƴ� seq�� �Ѿ�� ���");
					return -1;
				}
			}else {
				System.out.println("seq�� ���̰� 0�� ���");
				return -1;
			}
		}else {
			System.out.println("seq�� �Ѿ���� ���� ���");
			return -1;
		}
	}
}
