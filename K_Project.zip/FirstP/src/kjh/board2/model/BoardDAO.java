package kjh.board2.model;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import java.util.*;
import java.io.File;
import java.sql.*;

class BoardDAO {
	private DataSource ds;

	BoardDAO() {
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/myoracle");
		} catch (NamingException ne) {
		}
	}
	
	int getTotal() {
		int cnt = 0;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = ds.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(BoardSQL.SQL_TOTAL);
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
			return cnt;
		} catch (SQLException se) {		
			return cnt;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		} 		
	}

	ArrayList<BoardDTO> select(String searchKey, String searchValue,int begin,int end) {
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();		
		Connection con = null;
		Statement stmt = null;
		PreparedStatement pstmt1, pstmt2, pstmt3,pstmtPage = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			stmt = con.createStatement();
			pstmt1 = con.prepareStatement(BoardSQL.sqlS4);
			pstmt2 = con.prepareStatement(BoardSQL.sqlS5);
			pstmt3 = con.prepareStatement(BoardSQL.sqlS6);
			pstmtPage = con.prepareStatement(BoardSQL.SQL_SP);
			rs = stmt.executeQuery(BoardSQL.sqlS);
			if (searchValue == null || searchValue.equals("")) {
				//rs = stmt.executeQuery(BoardSQL.sqlS);
				pstmtPage.setInt(1,begin);
				pstmtPage.setInt(2,end);
				rs = pstmtPage.executeQuery();				
			} else {
				if (searchKey.equals("seq")) {
					searchValue = searchValue.trim();
					pstmt1.setString(1, searchValue);
					rs = pstmt1.executeQuery();
				} else if (searchKey.equals("writer")) {
					searchValue = searchValue.trim();
					pstmt2.setString(1, searchValue);
					rs = pstmt2.executeQuery();
				} else if (searchKey.equals("subject")) {
					searchValue = searchValue.trim();
					pstmt3.setString(1, searchValue);
					rs = pstmt3.executeQuery();
				} else {
					//rs = stmt.executeQuery(BoardSQL.sqlS);
					pstmtPage.setInt(1,begin);
					pstmtPage.setInt(2,end);
					rs = pstmtPage.executeQuery();					
				}
			}
			while (rs.next()) {
				int seq = rs.getInt(2);
				String subject = rs.getString(3);
				String content = rs.getString(4);
				String writer = rs.getString(5);
				java.sql.Date rdate = rs.getDate(6);
				int lookup = rs.getInt(7);
				String email = rs.getString(8);
				String homepage = rs.getString(9);
				String pwd = rs.getString(10);
				String fname = rs.getString(11);
				String ofname = rs.getString(12);
				int board_num = rs.getInt(13);
				int board_lv = rs.getInt(14);
				int board_sb = rs.getInt(15);
				BoardDTO dto = new BoardDTO(seq, subject, content, writer, rdate, lookup, email, homepage, pwd, fname,
						ofname, board_num, board_lv, board_sb);
				list.add(dto);				
			}
			return list;
		} catch (SQLException se) {
			System.out.println(se);
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if(pstmtPage!=null)
					pstmtPage.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	void insert(BoardDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.sqlI);
			pstmt.setString(1, dto.getSubject());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getWriter());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getHomepage());
			pstmt.setString(6, dto.getPwd());
			pstmt.setString(7, dto.getFname());
			pstmt.setString(8, dto.getOfname());

			pstmt.executeUpdate();
		} catch (SQLException se) {
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	int lookUp(BoardDTO dto) {
		int lookup = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.SQL_LOOK);
			pstmt.setInt(1, dto.getLookup());
			pstmt.setInt(2, dto.getSeq());
			pstmt.executeUpdate();

			pstmt2 = con.prepareStatement(BoardSQL.SQL_SELLOOK);
			pstmt2.setInt(1, dto.getSeq());
			rs = pstmt2.executeQuery();
			rs.next();
			lookup = rs.getInt(1);
			return lookup;
		} catch (SQLException se) {
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt2 != null)
					pstmt2.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return lookup;
	}

	BoardDTO content(int seq) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.sqlS2);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			rs.next();
			int seqNum = rs.getInt(1);
			String subject = rs.getString(2);
			String content = rs.getString(3);
			String writer = rs.getString(4);
			java.sql.Date rdate = rs.getDate(5);
			int lookup = rs.getInt(6);
			String email = rs.getString(7);
			String homepage = rs.getString(8);
			String fname = rs.getString(10);
			int bn = rs.getInt(12);
			int bl = rs.getInt(13);
			int sb = rs.getInt(14);
			BoardDTO dto = new BoardDTO(seqNum, subject, content, writer, rdate, lookup, email, homepage, null, fname,
					null, bn, bl, sb);
			return dto;
		} catch (SQLException se) {
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	void delete(int seq) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.sqlD);
			pstmt.setInt(1, seq);
			pstmt.executeUpdate();
		} catch (SQLException se) {
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	BoardDTO updateForm(int seq) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.sqlS2);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			rs.next();
			String subject = rs.getString(2);
			String content = rs.getString(3);
			String writer = rs.getString(4);
			String email = rs.getString(7);
			String homepage = rs.getString(8);
			String pwd = rs.getString(9);
			int bn = rs.getInt(12);
			int bl = rs.getInt(13);
			int sb = rs.getInt(14);
			BoardDTO dto = new BoardDTO(-1, subject, content, writer, null, -1, email, homepage, pwd, null, null, bn,
					bl, sb);
			return dto;
		} catch (SQLException se) {
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	void update(BoardDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.sqlU);
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getSubject());
			pstmt.setString(3, dto.getContent());
			pstmt.setInt(4, dto.getSeq());
			pstmt.executeUpdate();
		} catch (SQLException se) {
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
	}

	BoardDTO rewriteForm(int seq) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.SQL_REFORM);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			rs.next();
			String subject = rs.getString(1);
			int bn = rs.getInt(2);
			int bl = rs.getInt(3);
			int sb = rs.getInt(4);
			BoardDTO dto = new BoardDTO();
			dto.setSubject(subject);
			dto.setBoard_Num(bn);
			dto.setBoard_Lv(bl);
			dto.setBoard_Sb(sb);
			return dto;
		} catch (SQLException se) {
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return null;
	}

	void rewrite(BoardDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.SQL_RW);
			pstmt.setString(1, dto.getSubject());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getWriter());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getHomepage());
			pstmt.setString(6, dto.getPwd());
			pstmt.setString(7, dto.getFname());
			pstmt.setString(8, dto.getOfname());
			pstmt.setInt(9, dto.getBoard_Num());
			pstmt.setInt(10, dto.getBoard_Lv());
			pstmt.setInt(11, dto.getBoard_Sb());
			pstmt.executeQuery();
		} catch (SQLException se) {
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
	}

	void sbUpdate(int bn,int sb) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ds.getConnection();
			pstmt = con.prepareStatement(BoardSQL.SQL_SBUP);
			pstmt.setInt(1,bn);
			pstmt.setInt(2,sb);
			pstmt.executeUpdate();
		} catch (SQLException e) {		
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
	}
}
