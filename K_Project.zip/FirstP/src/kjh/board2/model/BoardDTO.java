package kjh.board2.model;

import java.sql.*;

public class BoardDTO {
	private int seq;
	private String subject;
	private String content;
	private String writer;
	private Date rdate;
	private int lookup;
	private String email;
	private String homepage;
	private String pwd;
	private String fname;
	private String ofname;
	private int board_num;
	private int board_lv;
	private int board_sb;
	
	public BoardDTO(){}

	public BoardDTO(int seq, String subject, String content, String writer, Date rdate, int lookup, String email,
			String homepage, String pwd, String fname, String ofname, int board_num,int board_lv,int board_sb) {
		this.seq = seq;
		this.subject = subject;
		this.content = content;
		this.writer = writer;
		this.rdate = rdate;
		this.lookup = lookup;
		this.email = email;
		this.homepage = homepage;
		this.pwd = pwd;
		this.fname = fname;
		this.ofname = ofname;
		this.board_num = board_num;
		this.board_lv = board_lv;
		this.board_sb = board_sb;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public Date getRdate() {
		return rdate;
	}

	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}

	public int getLookup() {
		return lookup;
	}

	public void setLookup(int lookup) {
		this.lookup = lookup;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getOfname() {
		return ofname;
	}

	public void setOfname(String ofname) {
		this.ofname = ofname;
	}
	
	public int getBoard_Num() {
		return board_num;
	}

	public void setBoard_Num(int board_num) {
		this.board_num = board_num;
	}
	
	public int getBoard_Lv() {
		return board_lv;
	}
	public void setBoard_Lv(int board_lv) {
		this.board_lv = board_lv;
	}
	public int getBoard_Sb() {
		return board_sb;
	}
	public void setBoard_Sb(int board_sb) {
		this.board_sb = board_sb;
	}
}
