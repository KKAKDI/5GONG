package kjh.board2.model;

class BoardSQL {
	static final String sqlS = "select *from BOARD2 order by BOARD_NUM desc,BOARD_SB asc,BOARD_LV asc";
	static final String SQL_SP = "select B.* from(select Rownum AS rn,A.* from (select *from BOARD2 order by BOARD_NUM desc,BOARD_SB asc,BOARD_LV asc)A)B where RN>=? and RN<=?";
	static final String SQL_TOTAL = "select count(*) from BOARD2";
	static final String sqlI = "insert into BOARD2 values(BOARD2_SEQ.nextval, ?, ?, ?, SYSDATE, 0, ?, ?, ?, ?, ?, BOARD_NUM.nextval,0,0)";
	static final String sqlS2 = "select *from BOARD2 where SEQ=?";
	static final String sqlD = "delete from BOARD2 where SEQ=?";
	static final String sqlS3 = "select SEQ, WRITER, EMAIL, SUBJECT, CONTENT from BOARD where SEQ=?";
	static final String sqlU = "update BOARD2 set EMAIL=?, SUBJECT=?, CONTENT=? where SEQ=?";
	static final String sqlS4 = "select *from BOARD2 where seq=? order by SEQ desc";
	static final String sqlS5 = "select *from BOARD2 where writer LIKE '%' || ? || '%' order by SEQ desc";
	static final String sqlS6 = "select *from BOARD2 where subject LIKE '%' || ? || '%' order by SEQ desc";
	static final String SQL_LOOK = "update BOARD2 set LOOKUP=? where SEQ=?";
	static final String SQL_SELLOOK = "select LOOKUP from BOARD2 where SEQ=?";
	static final String SQL_REFORM = "select SUBJECT,BOARD_NUM,BOARD_LV,BOARD_SB from BOARD2 where SEQ=?";
	static final String SQL_RW= "insert into BOARD2 values(BOARD2_SEQ.nextval,?,?,?,SYSDATE,0,?,?,?,?,?,?,?,?)";
	static final String SQL_SBUP= "update BOARD2 set BOARD_SB = BOARD_SB+1 where  BOARD_NUM = ? and BOARD_SB>=?";
}
