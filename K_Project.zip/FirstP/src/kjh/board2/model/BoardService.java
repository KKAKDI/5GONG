package kjh.board2.model;

import java.util.*;

public class BoardService {
	private BoardDAO dao;
	private static BoardService instance = new BoardService();
	private BoardService() {
		dao = new BoardDAO();
	}
	public static BoardService getInstance() {
		return instance;
	}
	public ArrayList<BoardDTO> selectS(String searchKey, String searchValue,int begin, int end){
		return dao.select(searchKey, searchValue,begin,end);
	}
	
	public int getTotalS() {
		return dao.getTotal();
	}
	public void insertS(BoardDTO dto) {
		dao.insert(dto);
	}
	public BoardDTO contentS(int seq) {
		return dao.content(seq);
	}
	
	public int lookUpS(BoardDTO dto ) {
		return dao.lookUp(dto);
	}
	public void deleteS(int seq) {
		dao.delete(seq);
	}
	public BoardDTO rewriteFormS(int seq) {			
		return dao.rewriteForm(seq);
	}
	public void rewriteS(BoardDTO dto) {
		dao.rewrite(dto);
	}
	public void sbUpdateS(int bn,int sb) {
		dao.sbUpdate(bn, sb);
	}
}
