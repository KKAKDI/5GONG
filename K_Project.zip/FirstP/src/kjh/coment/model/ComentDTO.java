package kjh.coment.model;

import java.sql.Date;

public class ComentDTO {
	private int idx;
	private String writer;
	private String pwd;
	private String content;
	private Date wdate;
	private String id;
	private int seq;
	
	public ComentDTO() {}
	
	public ComentDTO(int idx, String writer, String pwd, String content, Date wdate, String id, int seq) {
		super();
		this.idx = idx;
		this.writer = writer;
		this.pwd = pwd;
		this.content = content;
		this.wdate = wdate;
		this.id = id;
		this.seq = seq;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getWdate() {
		return wdate;
	}
	public void setWdate(Date wdate) {
		this.wdate = wdate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
}
