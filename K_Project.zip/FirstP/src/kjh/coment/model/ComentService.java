package kjh.coment.model;

import java.util.*;

public class ComentService {
	private ComentDAO dao;
	private static ComentService instance = new ComentService();
	private ComentService() {
		dao = new ComentDAO();
	}
	public static ComentService getInstance() {
		return instance;
	}
	
	public ArrayList<ComentDTO> selCmS(int seq) {
		return dao.selCm(seq);
		
	}
	public void inCmS(ComentDTO dto) {
		dao.inCm(dto);
	}
	public void delCmS(int idx) {
		dao.delCm(idx);
	}
}
