package kjh.coment.model;

class ComentSQL {
	static final String SQL_IN = "insert into REPLY values(IDX_SEQ.nextval,?,?,?,SYSDATE,?,?)";
	static final String SQL_SEL = "select * from REPLY where REPLY_IDX_FK=?";
	static final String SQL_DEL = "delete from REPLY where IDX_REPLY=?";
}
