package kjh.addr.control;

import java.io.IOException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kjh.addr.model.AddrDTO;
import kjh.addr.model.AddrService;


@WebServlet("/addr.do")
public class AddrControl extends HttpServlet {
	private static final long serialVersionUID = 1L;   

	
	public void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String m = request.getParameter("m");
		System.out.println(m);
		if(m!=null) {
			m=m.trim();
			if(m.equals("in_form")) {
				in_form(request,response);
			}else if(m.equals("in")) {
				in(request,response);
			}else if(m.equals("del")) {
				del(request,response);
			}else {
				list(request,response);
			}
		}else {
			list(request,response);
		}			
	}	
	private void list(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		AddrService service = AddrService.getInstance();
		ArrayList<AddrDTO> list = service.selectS();
		request.setAttribute("list", list);		
		RequestDispatcher rd =request.getRequestDispatcher("addr/list.jsp");
		rd.forward(request, response);		
	}
	private void in_form(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.sendRedirect("addr/input.jsp");
	}
	private void in(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String addr = request.getParameter("addr");		
		AddrDTO dto = new AddrDTO(-1,name,addr,null);
		AddrService service = AddrService.getInstance();
		service.insertS(dto);
		//list(request,response);		
		response.sendRedirect("addr.do");
	}
	private int getSeq(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String seqVal = request.getParameter("seq");
		if(seqVal!=null) {
			seqVal=seqVal.trim();
			if(seqVal.length()!=0) {
				try {
					int seq = Integer.parseInt(seqVal);	
					return seq;				
				} catch (NumberFormatException nfe) {
					System.out.println("seq ���� ���ڰ� �ƴ�");					
					return -1;
				}			
			}else {
				System.out.println("seq ���̰� 0��");			
				return -1;
			}			
		}else{
			System.out.println("seq ���� null");		
			return -1;
		}
	}
	private void del(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {	
		int seq = getSeq(request,response);
		if(seq!=-1) {
			AddrService service = AddrService.getInstance();			
			service.deleteS(seq);					
		}else {
		}
		response.sendRedirect("addr.do");
	}
}
