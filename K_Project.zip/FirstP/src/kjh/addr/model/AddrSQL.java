package kjh.addr.model;

class AddrSQL {
	static final String SQL_IN = "insert into ADDRESS values(ADDRESS_SEQ.nextval,?,?,SYSDATE)";
	static final String SQL_DEL = "delete from ADDRESS where SEQ=?";
	static final String SQL_SEL = "select * from ADDRESS order by SEQ desc";
}
