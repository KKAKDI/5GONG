package kjh.board.control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kjh.addr.model.AddrService;
import kjh.board.model.BoardDTO;
import kjh.board.model.BoardService;

/**
 * Servlet implementation class BoardControl
 */
@WebServlet("/board.do")
public class BoardControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String b = request.getParameter("b");
		if (b != null) {
			b = b.trim();
			System.out.println(b);
			if (b.equals("in_form")) {
				in_form(request, response);
			} else if (b.equals("in")) {
				insert(request, response);
			} else if (b.equals("con")) {
				content(request, response);
			} else if (b.equals("del")) {
				del(request, response);
			} else if (b.equals("up_sel")) {
				upselect(request, response);
			} else if (b.equals("up")) {
				update(request, response);
			} else {
				list(request, response);
			}
		} else {
			list(request, response);
		}
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BoardService service = BoardService.getInstance();
		ArrayList<BoardDTO> blist = service.selectS();
		request.setAttribute("boardlist", blist);
		RequestDispatcher rd = request.getRequestDispatcher("board/blist.jsp");
		rd.forward(request, response);
	}

	private void in_form(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("board/input.jsp");
	}

	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String writer = request.getParameter("writer");
		String email = request.getParameter("email");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		BoardDTO dto = new BoardDTO(-1, writer, email, subject, content, null);
		BoardService service = BoardService.getInstance();
		service.insertS(dto);
		response.sendRedirect("board.do");
	}

	private int getSeq(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String seqVal = request.getParameter("seq");
		if (seqVal != null) {
			seqVal = seqVal.trim();
			if (seqVal.length() != 0) {
				try {
					int seq = Integer.parseInt(seqVal);
					return seq;
				} catch (NumberFormatException nfe) {
					System.out.println("seq ���� ���ڰ� �ƴ�");
					return -1;
				}
			} else {
				System.out.println("seq ���̰� 0��");
				return -1;
			}
		} else {
			System.out.println("seq ���� null");
			return -1;
		}
	}

	private void del(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int seq = getSeq(request, response);
		if (seq != -1) {
			BoardService service = BoardService.getInstance();
			service.deleteS(seq);
		} else {
		}
		response.sendRedirect("board.do");
	}

	private void content(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int seq = getSeq(request, response);		
		BoardService service = BoardService.getInstance();
		if (seq != -1) {
		BoardDTO bcon = service.selseqS(seq);
		request.setAttribute("bcontent", bcon);
		RequestDispatcher rd = request.getRequestDispatcher("board/bcontent.jsp");
		rd.forward(request, response);
		}else {		
			response.sendRedirect("board.do");
		}		
	}

	private void upselect(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int seq = getSeq(request, response);
		BoardService service = BoardService.getInstance();
		if (seq != -1) {
		BoardDTO upsel = service.selseqS(seq);
		request.setAttribute("uplist", upsel);
		RequestDispatcher rd = request.getRequestDispatcher("board/upselect.jsp");
		rd.forward(request, response);
		}else {		
			response.sendRedirect("board.do");
		}
	}
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BoardService service = BoardService.getInstance();
		int seq = getSeq(request, response);
		String writer = request.getParameter("writer");
		String email = request.getParameter("email");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		BoardDTO dto = new BoardDTO(seq, writer, email, subject, content, null);
		service.updateS(dto);
		response.sendRedirect("board.do");
	}
}
