package kjh.board.model;

import java.util.*;

public class BoardService {
	private BoardDAO dao;
	private static BoardService instance = new BoardService();
	
	private BoardService() {
		dao = new BoardDAO();
	}
	public static BoardService getInstance() {
		return instance;
	}
	public ArrayList<BoardDTO> selectS(){
		return dao.selboard();
	}
	public void insertS(BoardDTO dto) {
		dao.inboard(dto);
	}
	public void deleteS(int seq) {
		dao.delboard(seq);
	}
	public void updateS(BoardDTO dto) {
		dao.upboard(dto);
	}
	public BoardDTO selseqS(int seq) {
		return dao.selseq(seq);
	}
}
