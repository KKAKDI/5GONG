package kjh.board.model;

class BoardSQL {
	static final String SQL_IN = "insert into BOARD values(BOARD_SEQ.nextval,?,?,?,?,SYSDATE)";
	static final String SQL_DEL =  "delete from BOARD where SEQ=?";			
	static final String SQL_SEL = "select * from BOARD order by SEQ desc";
	static final String SQL_SELSEQ = "select * from BOARD where SEQ=?";
	static final String SQL_UP = "update BOARD set EMAIL=?,SUBJECT=?,CONTENT=?,RDATE=SYSDATE where SEQ=?";
}
